This is an api created for e-commerce website.
Through this api user can perform the following functions:
  1) User can list all the products available.
  2) User can sort the products on the basis of name, price, company of the products.
  3) Here I also add the pagination property.
